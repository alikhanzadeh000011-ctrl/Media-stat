package com.media.cc;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.palette.graphics.Palette;

import java.io.InputStream;
import java.net.URL;
import java.util.List;
import java.util.Locale;

public class NowPlayingActivity extends Activity {

    /** ImageView that is always as tall as it is wide. */
    static class SquareImage extends ImageView {
        SquareImage(android.content.Context c) { super(c); }
        @Override
        protected void onMeasure(int w, int h) { super.onMeasure(w, w); }
    }

    private MediaSessionManager msm;
    private AudioManager am;
    private ComponentName listener;
    private MediaController controller;

    private FrameLayout root;
    private GradientDrawable bg;
    private SquareImage cover;
    private TextView title, artist, tPos, tRem, chip;
    private SeekBar prog, vol;
    private ImageView playBtn;
    private boolean seeking = false;
    private boolean noAccess = false;

    private int[] curColors = new int[]{0xFF6B5A86, 0xFF352B45, 0xFF0F0C14};
    private String curKey = "";
    private final Handler h = new Handler(Looper.getMainLooper());

    private final MediaController.Callback cb = new MediaController.Callback() {
        @Override public void onPlaybackStateChanged(PlaybackState s) { refresh(); }
        @Override public void onMetadataChanged(MediaMetadata m) { refresh(); }
        @Override public void onSessionDestroyed() { pick(); }
    };

    private final MediaSessionManager.OnActiveSessionsChangedListener sessionsL =
            new MediaSessionManager.OnActiveSessionsChangedListener() {
                @Override public void onActiveSessionsChanged(List<MediaController> l) { pick(); }
            };

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            updateProgress();
            updateVolume();
            h.postDelayed(this, 500);
        }
    };

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private GradientDrawable pill(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        setShowWhenLocked(true);

        msm = (MediaSessionManager) getSystemService(MEDIA_SESSION_SERVICE);
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        listener = new ComponentName(this, MediaListener.class);

        buildUi();
        applyColors(curColors, false);
    }

    private void buildUi() {
        root = new FrameLayout(this);
        bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, curColors);
        root.setBackground(bg);
        root.setOnClickListener(v -> finish());

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(pill(0x8C000000, 40));
        card.setPadding(dp(26), dp(26), dp(26), dp(22));
        card.setClickable(true);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        cp.leftMargin = dp(26);
        cp.rightMargin = dp(26);
        root.addView(card, cp);

        // cover
        cover = new SquareImage(this);
        cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
        cover.setBackground(pill(0x33FFFFFF, 12));
        cover.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(12));
            }
        });
        cover.setClipToOutline(true);
        card.addView(cover, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // title + artist
        title = new TextView(this);
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 21);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.topMargin = dp(22);
        card.addView(title, tp);

        artist = new TextView(this);
        artist.setTextColor(0xB3FFFFFF);
        artist.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19);
        artist.setSingleLine(true);
        artist.setEllipsize(android.text.TextUtils.TruncateAt.END);
        card.addView(artist, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // progress
        prog = makeBar(6);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(24));
        pp.topMargin = dp(18);
        card.addView(prog, pp);
        prog.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (fromUser) tPos.setText(fmt(p));
            }
            @Override public void onStartTrackingTouch(SeekBar s) { seeking = true; }
            @Override public void onStopTrackingTouch(SeekBar s) {
                seeking = false;
                if (controller != null) controller.getTransportControls().seekTo(s.getProgress());
            }
        });

        LinearLayout times = new LinearLayout(this);
        times.setOrientation(LinearLayout.HORIZONTAL);
        tPos = timeText();
        tRem = timeText();
        tRem.setGravity(Gravity.END);
        times.addView(tPos, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        times.addView(tRem, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        card.addView(times, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // controls
        LinearLayout ctr = new LinearLayout(this);
        ctr.setOrientation(LinearLayout.HORIZONTAL);
        ctr.setGravity(Gravity.CENTER_VERTICAL);
        ImageView prev = ctrlBtn(R.drawable.ic_rew, 56);
        playBtn = ctrlBtn(R.drawable.ic_play, 72);
        ImageView next = ctrlBtn(R.drawable.ic_ff, 56);
        ctr.addView(prev, new LinearLayout.LayoutParams(0, dp(72), 1));
        ctr.addView(playBtn, new LinearLayout.LayoutParams(0, dp(72), 1));
        ctr.addView(next, new LinearLayout.LayoutParams(0, dp(72), 1));
        LinearLayout.LayoutParams cr = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cr.topMargin = dp(14);
        card.addView(ctr, cr);
        prev.setOnClickListener(v -> { if (controller != null) controller.getTransportControls().skipToPrevious(); });
        next.setOnClickListener(v -> { if (controller != null) controller.getTransportControls().skipToNext(); });
        playBtn.setOnClickListener(v -> {
            if (controller == null) return;
            PlaybackState s = controller.getPlaybackState();
            if (s != null && s.getState() == PlaybackState.STATE_PLAYING) controller.getTransportControls().pause();
            else controller.getTransportControls().play();
        });

        // volume
        LinearLayout vrow = new LinearLayout(this);
        vrow.setOrientation(LinearLayout.HORIZONTAL);
        vrow.setGravity(Gravity.CENTER_VERTICAL);
        ImageView lo = new ImageView(this);
        lo.setImageResource(R.drawable.ic_vol_low);
        lo.setImageAlpha(150);
        ImageView hi = new ImageView(this);
        hi.setImageResource(R.drawable.ic_vol_high);
        hi.setImageAlpha(150);
        vol = makeBar(8);
        vol.setMax(am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        vol.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (fromUser) am.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        vrow.addView(lo, new LinearLayout.LayoutParams(dp(22), dp(22)));
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(0, dp(28), 1);
        vp.leftMargin = dp(12);
        vp.rightMargin = dp(12);
        vrow.addView(vol, vp);
        vrow.addView(hi, new LinearLayout.LayoutParams(dp(22), dp(22)));
        LinearLayout.LayoutParams vr = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        vr.topMargin = dp(14);
        card.addView(vrow, vr);

        // output device chip
        chip = new TextView(this);
        chip.setTextColor(Color.WHITE);
        chip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        chip.setSingleLine(true);
        chip.setGravity(Gravity.CENTER);
        chip.setBackground(pill(0x26FFFFFF, 30));
        chip.setPadding(dp(22), dp(10), dp(22), dp(10));
        chip.setVisibility(View.GONE);
        LinearLayout.LayoutParams chp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        chp.gravity = Gravity.CENTER_HORIZONTAL;
        chp.topMargin = dp(14);
        card.addView(chip, chp);

        setContentView(root);
    }

    private TextView timeText() {
        TextView t = new TextView(this);
        t.setTextColor(0xB3FFFFFF);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        t.setText("0:00");
        return t;
    }

    private ImageView ctrlBtn(int res, int sizeDp) {
        ImageView v = new ImageView(this);
        v.setImageResource(res);
        v.setScaleType(ImageView.ScaleType.FIT_CENTER);
        int pad = dp((72 - sizeDp) / 2f);
        v.setPadding(pad, pad, pad, pad);
        return v;
    }

    private SeekBar makeBar(int trackDp) {
        SeekBar s = new SeekBar(this);
        GradientDrawable track = pill(0x40FFFFFF, 10);
        GradientDrawable fill = pill(0xE6FFFFFF, 10);
        ClipDrawable clip = new ClipDrawable(fill, Gravity.START, ClipDrawable.HORIZONTAL);
        LayerDrawable ld = new LayerDrawable(new android.graphics.drawable.Drawable[]{track, clip});
        ld.setId(0, android.R.id.background);
        ld.setId(1, android.R.id.progress);
        int inset = Math.max(0, dp(12) - dp(trackDp) / 2);
        ld.setLayerInset(0, 0, inset, 0, inset);
        ld.setLayerInset(1, 0, inset, 0, inset);
        s.setProgressDrawable(ld);
        s.setThumb(new ColorDrawable(Color.TRANSPARENT));
        s.setThumbOffset(0);
        s.setPadding(0, 0, 0, 0);
        s.setSplitTrack(false);
        return s;
    }

    @Override
    protected void onStart() {
        super.onStart();
        try {
            msm.addOnActiveSessionsChangedListener(sessionsL, listener);
            noAccess = false;
        } catch (SecurityException e) {
            noAccess = true;
        }
        pick();
        h.post(tick);
    }

    @Override
    protected void onStop() {
        super.onStop();
        h.removeCallbacksAndMessages(null);
        try { msm.removeOnActiveSessionsChangedListener(sessionsL); } catch (Exception ignored) {}
        if (controller != null) {
            try { controller.unregisterCallback(cb); } catch (Exception ignored) {}
            controller = null;
        }
    }

    private void pick() {
        MediaController best = null;
        try {
            List<MediaController> l = msm.getActiveSessions(listener);
            noAccess = false;
            for (MediaController c : l) {
                PlaybackState s = c.getPlaybackState();
                if (s != null && s.getState() == PlaybackState.STATE_PLAYING) { best = c; break; }
            }
            if (best == null && !l.isEmpty()) best = l.get(0);
        } catch (SecurityException e) {
            noAccess = true;
        }
        if (controller != null) {
            try { controller.unregisterCallback(cb); } catch (Exception ignored) {}
        }
        controller = best;
        if (controller != null) controller.registerCallback(cb, h);
        refresh();
    }

    private void refresh() {
        if (controller == null) {
            title.setText(noAccess ? "Notification Access is off" : "Nothing playing");
            artist.setText(noAccess ? "Tap here to open setup" : "");
            title.setOnClickListener(noAccess ? (View.OnClickListener) v ->
                    startActivity(new Intent(this, MainActivity.class)) : null);
            cover.setImageResource(R.drawable.ic_note);
            cover.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            cover.setPadding(dp(60), dp(60), dp(60), dp(60));
            playBtn.setImageResource(R.drawable.ic_play);
            prog.setMax(1);
            prog.setProgress(0);
            tPos.setText("0:00");
            tRem.setText("-0:00");
            applyColors(new int[]{0xFF6B5A86, 0xFF352B45, 0xFF0F0C14}, true);
            curKey = "";
            updateChip();
            return;
        }
        title.setOnClickListener(null);

        MediaMetadata m = controller.getMetadata();
        String t = null, a = null;
        if (m != null) {
            t = m.getString(MediaMetadata.METADATA_KEY_TITLE);
            if (t == null) t = m.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE);
            a = m.getString(MediaMetadata.METADATA_KEY_ARTIST);
            if (a == null) a = m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST);
            if (a == null) a = m.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE);
        }
        title.setText(t == null ? "Unknown" : t);
        artist.setText(a == null ? "" : a);

        PlaybackState s = controller.getPlaybackState();
        boolean playing = s != null && s.getState() == PlaybackState.STATE_PLAYING;
        playBtn.setImageResource(playing ? R.drawable.ic_pause : R.drawable.ic_play);

        loadCover(m, t + "|" + a);
        updateChip();
        updateProgress();
    }

    private void loadCover(MediaMetadata m, String key) {
        if (key.equals(curKey) && cover.getDrawable() != null) return;
        if (m == null) return;
        Bitmap bmp = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
        if (bmp == null) bmp = m.getBitmap(MediaMetadata.METADATA_KEY_ART);
        if (bmp == null) bmp = m.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
        if (bmp != null) {
            curKey = key;
            setCover(bmp);
            return;
        }
        String uri = m.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI);
        if (uri == null) uri = m.getString(MediaMetadata.METADATA_KEY_ART_URI);
        if (uri == null) uri = m.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI);
        if (uri != null) {
            curKey = key;
            final String u = uri;
            final String k = key;
            new Thread(() -> {
                Bitmap b = null;
                try {
                    InputStream in;
                    if (u.startsWith("http")) in = new URL(u).openStream();
                    else in = getContentResolver().openInputStream(Uri.parse(u));
                    if (in != null) { b = BitmapFactory.decodeStream(in); in.close(); }
                } catch (Exception ignored) {}
                final Bitmap fb = b;
                runOnUiThread(() -> { if (k.equals(curKey) && fb != null) setCover(fb); });
            }).start();
        }
    }

    private void setCover(Bitmap b) {
        cover.setPadding(0, 0, 0, 0);
        cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
        cover.setImageBitmap(b);
        try {
            Bitmap small = Bitmap.createScaledBitmap(b, 64, 64, true);
            Palette p = Palette.from(small).generate();
            Palette.Swatch sw = p.getDominantSwatch();
            if (sw != null) {
                float[] hsv = new float[3];
                Color.colorToHSV(sw.getRgb(), hsv);
                if (hsv[1] < 0.2f && p.getVibrantSwatch() != null) sw = p.getVibrantSwatch();
            }
            if (sw == null) sw = p.getMutedSwatch();
            int base = sw != null ? sw.getRgb() : 0xFF6B5A86;
            float[] hsv = new float[3];
            Color.colorToHSV(base, hsv);
            float v = Math.min(Math.max(hsv[2], 0.42f), 0.72f);
            if (hsv[1] < 0.12f) v = Math.min(v, 0.5f);
            int top = Color.HSVToColor(new float[]{hsv[0], hsv[1], v});
            int mid = Color.HSVToColor(new float[]{hsv[0], hsv[1], v * 0.5f});
            int bot = Color.HSVToColor(new float[]{hsv[0], Math.min(1f, hsv[1] * 0.9f), v * 0.14f});
            applyColors(new int[]{top, mid, bot}, true);
        } catch (Exception ignored) {}
    }

    private void applyColors(final int[] to, boolean animate) {
        final int[] from = curColors.clone();
        curColors = to;
        if (!animate) { bg.setColors(to); return; }
        ValueAnimator va = ValueAnimator.ofFloat(0f, 1f);
        va.setDuration(500);
        final ArgbEvaluator ev = new ArgbEvaluator();
        va.addUpdateListener(a -> {
            float f = (float) a.getAnimatedValue();
            bg.setColors(new int[]{
                    (int) ev.evaluate(f, from[0], to[0]),
                    (int) ev.evaluate(f, from[1], to[1]),
                    (int) ev.evaluate(f, from[2], to[2])});
        });
        va.start();
    }

    private void updateProgress() {
        if (controller == null || seeking) return;
        MediaMetadata m = controller.getMetadata();
        PlaybackState s = controller.getPlaybackState();
        long dur = m == null ? 0 : m.getLong(MediaMetadata.METADATA_KEY_DURATION);
        long pos = 0;
        if (s != null) {
            pos = s.getPosition();
            if (s.getState() == PlaybackState.STATE_PLAYING) {
                long dt = SystemClock.elapsedRealtime() - s.getLastPositionUpdateTime();
                pos += (long) (dt * s.getPlaybackSpeed());
            }
        }
        if (pos < 0) pos = 0;
        if (dur > 0) {
            if (pos > dur) pos = dur;
            prog.setMax((int) dur);
            prog.setProgress((int) pos);
            tRem.setText("-" + fmt(dur - pos));
        } else {
            prog.setMax(1);
            prog.setProgress(0);
            tRem.setText("");
        }
        tPos.setText(fmt(pos));
    }

    private void updateVolume() {
        if (vol != null) vol.setProgress(am.getStreamVolume(AudioManager.STREAM_MUSIC));
    }

    private void updateChip() {
        String name = null;
        try {
            for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                int t = d.getType();
                if (t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || t == AudioDeviceInfo.TYPE_WIRED_HEADPHONES
                        || t == AudioDeviceInfo.TYPE_WIRED_HEADSET || t == AudioDeviceInfo.TYPE_USB_HEADSET
                        || t == AudioDeviceInfo.TYPE_BLE_HEADSET) {
                    CharSequence n = d.getProductName();
                    name = n == null ? "Headphones" : n.toString();
                    break;
                }
            }
        } catch (Exception ignored) {}
        if (name == null) {
            chip.setVisibility(View.GONE);
        } else {
            chip.setText(name);
            chip.setVisibility(View.VISIBLE);
        }
    }

    private static String fmt(long ms) {
        long s = Math.max(0, ms / 1000);
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }
}
