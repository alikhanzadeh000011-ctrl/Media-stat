package com.media.cc;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** One-time setup screen. */
public class MainActivity extends Activity {

    private TextView status;
    private Button hideBtn;

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private Button button(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(16));
        b.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        lp.topMargin = dp(12);
        b.setLayoutParams(lp);
        return b;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF1B1524);
        getWindow().setNavigationBarColor(0xFF1B1524);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF1B1524);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(24), dp(48), dp(24), dp(32));
        sv.addView(col);

        TextView t = new TextView(this);
        t.setText("Media");
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 32);
        t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        col.addView(t);

        status = new TextView(this);
        status.setTextColor(0xCCFFFFFF);
        status.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        status.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        status.setGravity(Gravity.START);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.topMargin = dp(16);
        col.addView(status, sp);

        Button access = button("۱) فعال‌سازی Notification Access", 0xFF7B5EA7);
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        col.addView(access);

        Button restricted = button("اگر گزینه خاکستری بود: Allow restricted settings", 0xFF3A3050);
        restricted.setOnClickListener(v -> {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        });
        col.addView(restricted);

        TextView how = new TextView(this);
        how.setText("۲) کنترل سنتر را پایین بکش ← دکمه ویرایش (مداد) ← دکمه Media را به بالا بکش.\n\n"
                + "۳) آیکون برنامه را از لانچر مخفی کن (دکمه پایین). برای باز کردن دوباره این صفحه، روی دکمه Media در کنترل سنتر نگه دار.");
        how.setTextColor(0xCCFFFFFF);
        how.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        how.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        how.setGravity(Gravity.START);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hp.topMargin = dp(20);
        col.addView(how, hp);

        hideBtn = button("", 0xFF3A3050);
        hideBtn.setOnClickListener(v -> {
            setLauncherHidden(!isLauncherHidden());
            refresh();
        });
        col.addView(hideBtn);

        setContentView(sv);
    }

    private ComponentName alias() {
        return new ComponentName(this, "com.media.cc.Launcher");
    }

    private boolean isLauncherHidden() {
        return getPackageManager().getComponentEnabledSetting(alias())
                == PackageManager.COMPONENT_ENABLED_STATE_DISABLED;
    }

    private void setLauncherHidden(boolean hide) {
        getPackageManager().setComponentEnabledSetting(alias(),
                hide ? PackageManager.COMPONENT_ENABLED_STATE_DISABLED
                        : PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP);
    }

    private boolean hasAccess() {
        String s = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return s != null && s.contains(getPackageName());
    }

    private void refresh() {
        status.setText(hasAccess()
                ? "✅ دسترسی فعال است. فقط دکمه Media را به کنترل سنتر اضافه کن."
                : "❌ دسترسی Notification Access هنوز فعال نیست.");
        hideBtn.setText(isLauncherHidden() ? "نمایش دوباره آیکون در لانچر" : "مخفی کردن آیکون از لانچر");
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }
}
