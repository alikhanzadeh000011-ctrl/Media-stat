package com.media.cc;

import android.service.notification.NotificationListenerService;

/** Empty on purpose: holding Notification Access is what allows reading media sessions. */
public class MediaListener extends NotificationListenerService {
}
