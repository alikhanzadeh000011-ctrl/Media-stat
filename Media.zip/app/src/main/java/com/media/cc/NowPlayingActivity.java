package com.media.cc;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.InputStream;
import java.net.URL;
import java.util.List;
import java.util.Locale;

public class NowPlayingActivity extends Activity {

    /** ImageView that is always as tall as it is wide. */
    static class SquareImage extends ImageView {
        SquareImage(Context c) { super(c); }
        @Override
        protected void onMeasure(int w, int h) { super.onMeasure(w, w); }
    }

    /** iOS-style flat slider: rounded track, fill clipped at the current value. */
    static class Bar extends View {
        interface L {
            void onStart();
            void onChange(int p, boolean user);
            void onStop(int p);
        }

        int max = 1, progress = 0;
        float thick;
        int trackColor = 0x47FFFFFF, fillColor = 0xF2FFFFFF;
        boolean touchable = true;
        L l;
        final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        final RectF r = new RectF();

        Bar(Context c, float thick) {
            super(c);
            this.thick = thick;
        }

        void setValues(int max, int p) {
            this.max = Math.max(1, max);
            this.progress = Math.max(0, Math.min(p, this.max));
            invalidate();
        }

        void setFill(int c) {
            fillColor = c;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float w = getWidth();
            float top = (getHeight() - thick) / 2f;
            r.set(0, top, w, top + thick);
            paint.setColor(trackColor);
            canvas.drawRoundRect(r, thick / 2f, thick / 2f, paint);
            float fw = w * progress / (float) max;
            if (fw > 0) {
                canvas.save();
                canvas.clipRect(0, 0, fw, getHeight());
                paint.setColor(fillColor);
                canvas.drawRoundRect(r, thick / 2f, thick / 2f, paint);
                canvas.restore();
            }
        }

        private void update(float x, boolean user) {
            float f = Math.max(0f, Math.min(1f, x / Math.max(1f, getWidth())));
            progress = Math.round(max * f);
            invalidate();
            if (l != null) l.onChange(progress, user);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (!touchable) return true;
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    getParent().requestDisallowInterceptTouchEvent(true);
                    if (l != null) l.onStart();
                    update(e.getX(), true);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    update(e.getX(), true);
                    return true;
                case MotionEvent.ACTION_UP:
                    update(e.getX(), true);
                    if (l != null) l.onStop(progress);
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    if (l != null) l.onStop(progress);
                    return true;
            }
            return true;
        }
    }

    private MediaSessionManager msm;
    private AudioManager am;
    private ComponentName listener;
    private MediaController controller;

    private FrameLayout root;
    private GradientDrawable bg;
    private SquareImage cover;
    private TextView title, artist, tPos, tRem, chip;
    private Bar prog, vol;
    private ImageView playBtn;
    private boolean seeking = false;
    private boolean volDrag = false;
    private boolean noAccess = false;
    private long curDur = 0;

    private float s = 1f; // screen width / 1080 (the reference image is 1080 wide)
    private int W, H;

    private static final int[] DEFAULT_COLORS = new int[]{0xFF6B5A86, 0xFF352B45, 0xFF0F0C14};
    private int[] curColors = DEFAULT_COLORS;
    private String curKey = "";
    private final Handler h = new Handler(Looper.getMainLooper());

    private final MediaController.Callback cb = new MediaController.Callback() {
        @Override public void onPlaybackStateChanged(PlaybackState st) { refresh(); }
        @Override public void onMetadataChanged(MediaMetadata m) { refresh(); }
        @Override public void onSessionDestroyed() { pick(); }
    };

    private final MediaSessionManager.OnActiveSessionsChangedListener sessionsL =
            new MediaSessionManager.OnActiveSessionsChangedListener() {
                @Override public void onActiveSessionsChanged(List<MediaController> l) { pick(); }
            };

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            updateProgress();
            updateVolume();
            updateChip();
            h.postDelayed(this, 500);
        }
    };

    /** reference-image pixels -> real pixels */
    private int px(float ref) {
        return Math.round(ref * s);
    }

    private GradientDrawable pill(int color, float radiusPx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusPx);
        return g;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        setShowWhenLocked(true);

        W = getResources().getDisplayMetrics().widthPixels;
        H = getResources().getDisplayMetrics().heightPixels;
        s = W / 1080f;

        msm = (MediaSessionManager) getSystemService(MEDIA_SESSION_SERVICE);
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        listener = new ComponentName(this, MediaListener.class);

        buildUi();
        applyColors(curColors, false);
    }

    private TextView text(float sizeRefPx, int color, boolean medium) {
        TextView t = new TextView(this);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, sizeRefPx * s);
        t.setSingleLine(true);
        t.setIncludeFontPadding(false);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (medium) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return t;
    }

    private LinearLayout.LayoutParams lp(int w, int hgt, float topRef) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, hgt);
        p.topMargin = px(topRef);
        return p;
    }

    private ImageView icon(int res, float sizeRef) {
        ImageView v = new ImageView(this);
        v.setImageResource(res);
        v.setScaleType(ImageView.ScaleType.FIT_CENTER);
        v.setLayoutParams(new LinearLayout.LayoutParams(px(sizeRef), px(sizeRef)));
        return v;
    }

    private void buildUi() {
        root = new FrameLayout(this);
        bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, curColors);
        root.setBackground(bg);
        root.setOnClickListener(v -> finish());

        // ---- card (all measurements taken from the 1080 px wide reference) ----
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(pill(0x66000000, px(75)));
        card.setPadding(px(66), px(66), px(66), px(64));
        card.setClickable(true);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.START);
        cp.leftMargin = px(106);
        cp.rightMargin = px(106);
        cp.topMargin = Math.round(H * 360f / 2337f);
        root.addView(card, cp);

        // cover
        cover = new SquareImage(this);
        cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
        cover.setBackground(pill(0x33FFFFFF, px(30)));
        cover.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), px(30));
            }
        });
        cover.setClipToOutline(true);
        card.addView(cover, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // title + artist
        title = text(43, Color.WHITE, true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        card.addView(title, lp(ViewGroup.LayoutParams.MATCH_PARENT, px(56), 59));

        artist = text(41, 0x99FFFFFF, false);
        artist.setEllipsize(android.text.TextUtils.TruncateAt.END);
        card.addView(artist, lp(ViewGroup.LayoutParams.MATCH_PARENT, px(50), 0));

        // progress bar
        prog = new Bar(this, 18 * s);
        prog.l = new Bar.L() {
            @Override public void onStart() { seeking = true; }
            @Override public void onChange(int p, boolean user) {
                if (!user) return;
                tPos.setText(fmt(p));
                tRem.setText("-" + fmt(Math.max(0, curDur - p)));
            }
            @Override public void onStop(int p) {
                seeking = false;
                if (controller != null) controller.getTransportControls().seekTo(p);
            }
        };
        card.addView(prog, lp(ViewGroup.LayoutParams.MATCH_PARENT, px(40), 37));

        // times
        LinearLayout times = new LinearLayout(this);
        times.setOrientation(LinearLayout.HORIZONTAL);
        tPos = text(31, 0x99FFFFFF, false);
        tRem = text(31, 0x99FFFFFF, false);
        tRem.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        tPos.setText("0:00");
        tRem.setText("-0:00");
        times.addView(tPos, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));
        times.addView(tRem, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));
        card.addView(times, lp(ViewGroup.LayoutParams.MATCH_PARENT, px(40), 9));

        // controls (rewind / play / fast-forward)
        LinearLayout ctr = new LinearLayout(this);
        ctr.setOrientation(LinearLayout.HORIZONTAL);
        ctr.setGravity(Gravity.CENTER);
        ImageView prev = icon(R.drawable.ic_rew, 130);
        playBtn = icon(R.drawable.ic_play, 160);
        ImageView next = icon(R.drawable.ic_ff, 130);
        LinearLayout.LayoutParams pl = (LinearLayout.LayoutParams) playBtn.getLayoutParams();
        pl.leftMargin = px(71);
        pl.rightMargin = px(71);
        ctr.addView(prev);
        ctr.addView(playBtn);
        ctr.addView(next);
        card.addView(ctr, lp(ViewGroup.LayoutParams.MATCH_PARENT, px(160), 14));
        prev.setOnClickListener(v -> { if (controller != null) controller.getTransportControls().skipToPrevious(); });
        next.setOnClickListener(v -> { if (controller != null) controller.getTransportControls().skipToNext(); });
        playBtn.setOnClickListener(v -> {
            if (controller == null) return;
            PlaybackState st = controller.getPlaybackState();
            if (st != null && st.getState() == PlaybackState.STATE_PLAYING) controller.getTransportControls().pause();
            else controller.getTransportControls().play();
        });

        // volume row
        LinearLayout vrow = new LinearLayout(this);
        vrow.setOrientation(LinearLayout.HORIZONTAL);
        vrow.setGravity(Gravity.CENTER_VERTICAL);
        ImageView lo = new ImageView(this);
        lo.setImageResource(R.drawable.ic_vol_low);
        lo.setImageAlpha(160);
        ImageView hi = new ImageView(this);
        hi.setImageResource(R.drawable.ic_vol_high);
        hi.setImageAlpha(160);
        vol = new Bar(this, 20 * s);
        vol.l = new Bar.L() {
            @Override public void onStart() { volDrag = true; }
            @Override public void onChange(int p, boolean user) {
                if (user) am.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0);
            }
            @Override public void onStop(int p) { volDrag = false; }
        };
        vrow.addView(lo, new LinearLayout.LayoutParams(px(54), px(54)));
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(0, px(40), 1);
        vp.leftMargin = px(14);
        vp.rightMargin = px(14);
        vrow.addView(vol, vp);
        vrow.addView(hi, new LinearLayout.LayoutParams(px(73), px(73)));
        card.addView(vrow, lp(ViewGroup.LayoutParams.MATCH_PARENT, px(73), 47));

        // output device pill
        chip = text(36, Color.WHITE, false);
        chip.setGravity(Gravity.CENTER);
        chip.setBackground(pill(0x29FFFFFF, px(43)));
        chip.setPadding(px(38), 0, px(44), 0);
        Drawable bt = getDrawable(R.drawable.ic_bt);
        if (bt != null) {
            bt.setBounds(0, 0, px(46), px(46));
            chip.setCompoundDrawables(bt, null, null, null);
            chip.setCompoundDrawablePadding(px(14));
        }
        chip.setText("Phone");
        chip.setOnClickListener(v -> {
            try { startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); } catch (Exception ignored) {}
        });
        LinearLayout.LayoutParams chp = lp(ViewGroup.LayoutParams.WRAP_CONTENT, px(86), 32);
        chp.gravity = Gravity.CENTER_HORIZONTAL;
        card.addView(chip, chp);

        setContentView(root);
    }

    @Override
    protected void onStart() {
        super.onStart();
        try {
            msm.addOnActiveSessionsChangedListener(sessionsL, listener);
            noAccess = false;
        } catch (SecurityException e) {
            noAccess = true;
        }
        pick();
        h.post(tick);
    }

    @Override
    protected void onStop() {
        super.onStop();
        h.removeCallbacksAndMessages(null);
        try { msm.removeOnActiveSessionsChangedListener(sessionsL); } catch (Exception ignored) {}
        if (controller != null) {
            try { controller.unregisterCallback(cb); } catch (Exception ignored) {}
            controller = null;
        }
    }

    private void pick() {
        MediaController best = null;
        try {
            List<MediaController> l = msm.getActiveSessions(listener);
            noAccess = false;
            for (MediaController c : l) {
                PlaybackState st = c.getPlaybackState();
                if (st != null && st.getState() == PlaybackState.STATE_PLAYING) { best = c; break; }
            }
            if (best == null && !l.isEmpty()) best = l.get(0);
        } catch (SecurityException e) {
            noAccess = true;
        }
        if (controller != null) {
            try { controller.unregisterCallback(cb); } catch (Exception ignored) {}
        }
        controller = best;
        if (controller != null) controller.registerCallback(cb, h);
        refresh();
    }

    private void refresh() {
        if (controller == null) {
            title.setText(noAccess ? "Notification Access is off" : "Nothing playing");
            artist.setText(noAccess ? "Tap here to open setup" : "");
            if (noAccess) {
                title.setOnClickListener(v -> startActivity(new Intent(this, MainActivity.class)));
            } else {
                title.setOnClickListener(null);
            }
            cover.setImageResource(R.drawable.ic_note);
            cover.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            cover.setPadding(px(200), px(200), px(200), px(200));
            playBtn.setImageResource(R.drawable.ic_play);
            curDur = 0;
            prog.touchable = false;
            prog.setValues(1, 0);
            tPos.setText("0:00");
            tRem.setText("-0:00");
            applyColors(DEFAULT_COLORS, true);
            curKey = "";
            return;
        }
        title.setOnClickListener(null);

        MediaMetadata m = controller.getMetadata();
        String t = null, a = null;
        if (m != null) {
            t = m.getString(MediaMetadata.METADATA_KEY_TITLE);
            if (t == null) t = m.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE);
            a = m.getString(MediaMetadata.METADATA_KEY_ARTIST);
            if (a == null) a = m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST);
            if (a == null) a = m.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE);
        }
        title.setText(t == null ? "Unknown" : t);
        artist.setText(a == null ? "" : a);

        PlaybackState st = controller.getPlaybackState();
        boolean playing = st != null && st.getState() == PlaybackState.STATE_PLAYING;
        playBtn.setImageResource(playing ? R.drawable.ic_pause : R.drawable.ic_play);

        loadCover(m, t + "|" + a);
        updateProgress();
    }

    private void loadCover(MediaMetadata m, String key) {
        if (key.equals(curKey) && cover.getDrawable() != null) return;
        if (m == null) return;
        Bitmap bmp = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
        if (bmp == null) bmp = m.getBitmap(MediaMetadata.METADATA_KEY_ART);
        if (bmp == null) bmp = m.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
        if (bmp != null) {
            curKey = key;
            setCover(bmp);
            return;
        }
        String uri = m.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI);
        if (uri == null) uri = m.getString(MediaMetadata.METADATA_KEY_ART_URI);
        if (uri == null) uri = m.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI);
        if (uri != null) {
            curKey = key;
            final String u = uri;
            final String k = key;
            new Thread(() -> {
                Bitmap b = null;
                try {
                    InputStream in;
                    if (u.startsWith("http")) in = new URL(u).openStream();
                    else in = getContentResolver().openInputStream(Uri.parse(u));
                    if (in != null) { b = BitmapFactory.decodeStream(in); in.close(); }
                } catch (Exception ignored) {}
                final Bitmap fb = b;
                runOnUiThread(() -> { if (k.equals(curKey) && fb != null) setCover(fb); });
            }).start();
        }
    }

    private void setCover(Bitmap b) {
        cover.setPadding(0, 0, 0, 0);
        cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
        cover.setImageBitmap(b);
        try {
            applyColors(makeGradient(b), true);
        } catch (Exception ignored) {}
    }

    /**
     * Spotify-like gradient: find the hue that covers most of the cover (weighted by
     * saturation), not just the most common pixel colour, so a blue-sky cover gives blue.
     */
    private int[] makeGradient(Bitmap b) {
        final int N = 40;
        Bitmap sm = Bitmap.createScaledBitmap(b, N, N, true);
        int[] px = new int[N * N];
        sm.getPixels(px, 0, N, 0, 0, N, N);

        float[] hsv = new float[3];
        float[] w = new float[24], sh = new float[24], ss = new float[24], sv = new float[24];
        float total = 0, aR = 0, aG = 0, aB = 0;
        for (int c : px) {
            aR += Color.red(c);
            aG += Color.green(c);
            aB += Color.blue(c);
            Color.colorToHSV(c, hsv);
            if (hsv[1] < 0.25f || hsv[2] < 0.2f) continue;
            int bin = ((int) (hsv[0] / 15f)) % 24;
            float wt = hsv[1] * hsv[2];
            w[bin] += wt;
            sh[bin] += hsv[0] * wt;
            ss[bin] += hsv[1] * wt;
            sv[bin] += hsv[2] * wt;
            total += wt;
        }
        int n = px.length;

        if (total / n < 0.04f) {
            // (almost) black / white / grey cover -> neutral gradient from the average colour
            Color.colorToHSV(Color.rgb((int) (aR / n), (int) (aG / n), (int) (aB / n)), hsv);
            float v = Math.min(Math.max(hsv[2], 0.32f), 0.55f);
            float sat = Math.min(hsv[1], 0.35f);
            return new int[]{
                    Color.HSVToColor(new float[]{hsv[0], sat, v}),
                    Color.HSVToColor(new float[]{hsv[0], sat, v * 0.5f}),
                    Color.HSVToColor(new float[]{hsv[0], sat, v * 0.14f})};
        }

        int best = 0;
        float bestScore = -1;
        for (int i = 0; i < 24; i++) {
            float sc = w[i] + 0.5f * (w[(i + 23) % 24] + w[(i + 1) % 24]);
            if (sc > bestScore) { bestScore = sc; best = i; }
        }
        float W2 = 0, H2 = 0, S2 = 0, V2 = 0;
        for (int d = -1; d <= 1; d++) {
            int i = (best + d + 24) % 24;
            W2 += w[i];
            H2 += sh[i];
            S2 += ss[i];
            V2 += sv[i];
        }
        float hue = H2 / W2, sat = Math.min(1f, (S2 / W2) * 0.85f), val = V2 / W2;
        val = Math.min(Math.max(val, 0.5f), 0.74f);
        return new int[]{
                Color.HSVToColor(new float[]{hue, sat, val}),
                Color.HSVToColor(new float[]{hue, sat, val * 0.5f}),
                Color.HSVToColor(new float[]{hue, Math.min(1f, sat * 0.9f), val * 0.14f})};
    }

    private static int blend(int a, int b, float t) {
        return Color.rgb(
                (int) (Color.red(a) * (1 - t) + Color.red(b) * t),
                (int) (Color.green(a) * (1 - t) + Color.green(b) * t),
                (int) (Color.blue(a) * (1 - t) + Color.blue(b) * t));
    }

    private void applyColors(final int[] to, boolean animate) {
        final int[] from = curColors.clone();
        curColors = to;
        int fill = (0xF2 << 24) | (blend(to[0], 0xFFFFFFFF, 0.8f) & 0xFFFFFF);
        if (prog != null) prog.setFill(fill);
        if (vol != null) vol.setFill(fill);
        if (!animate) { bg.setColors(to); return; }
        ValueAnimator va = ValueAnimator.ofFloat(0f, 1f);
        va.setDuration(500);
        final ArgbEvaluator ev = new ArgbEvaluator();
        va.addUpdateListener(a -> {
            float f = (float) a.getAnimatedValue();
            bg.setColors(new int[]{
                    (int) ev.evaluate(f, from[0], to[0]),
                    (int) ev.evaluate(f, from[1], to[1]),
                    (int) ev.evaluate(f, from[2], to[2])});
        });
        va.start();
    }

    private void updateProgress() {
        if (controller == null || seeking) return;
        MediaMetadata m = controller.getMetadata();
        PlaybackState st = controller.getPlaybackState();
        long dur = m == null ? 0 : m.getLong(MediaMetadata.METADATA_KEY_DURATION);
        long pos = 0;
        if (st != null) {
            pos = st.getPosition();
            if (st.getState() == PlaybackState.STATE_PLAYING) {
                long dt = SystemClock.elapsedRealtime() - st.getLastPositionUpdateTime();
                pos += (long) (dt * st.getPlaybackSpeed());
            }
        }
        if (pos < 0) pos = 0;
        curDur = Math.max(0, dur);
        if (dur > 0) {
            if (pos > dur) pos = dur;
            prog.touchable = true;
            prog.setValues((int) dur, (int) pos);
            tRem.setText("-" + fmt(dur - pos));
        } else {
            prog.touchable = false;
            prog.setValues(1, 0);
            tRem.setText("");
        }
        tPos.setText(fmt(pos));
    }

    private void updateVolume() {
        if (vol == null || volDrag) return;
        vol.setValues(am.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
                am.getStreamVolume(AudioManager.STREAM_MUSIC));
    }

    private void updateChip() {
        String bt = null, wired = null;
        try {
            for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                int t = d.getType();
                CharSequence n = d.getProductName();
                String name = (n == null || n.length() == 0) ? "Headphones" : n.toString();
                if (t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || t == AudioDeviceInfo.TYPE_BLE_HEADSET
                        || t == AudioDeviceInfo.TYPE_BLE_SPEAKER || t == AudioDeviceInfo.TYPE_BLE_BROADCAST) {
                    if (bt == null) bt = name;
                } else if (t == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || t == AudioDeviceInfo.TYPE_WIRED_HEADSET
                        || t == AudioDeviceInfo.TYPE_USB_HEADSET) {
                    if (wired == null) wired = name;
                }
            }
        } catch (Exception ignored) {}
        String label = bt != null ? bt : (wired != null ? wired : "Phone");
        if (!label.contentEquals(chip.getText())) chip.setText(label);
    }

    private static String fmt(long ms) {
        long sec = Math.max(0, ms / 1000);
        return String.format(Locale.US, "%d:%02d", sec / 60, sec % 60);
    }
}
